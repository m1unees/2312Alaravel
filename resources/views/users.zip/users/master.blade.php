<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>@yield('title', 'Medicio')</title>

    <!-- Fonts -->
    <link href="https://fonts.googleapis.com" rel="preconnect">
    <link href="https://fonts.gstatic.com" rel="preconnect" crossorigin>
    <!-- <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@100;300;400;500;700;900&family=Poppins:wght@100;200;300;400;500;600;700;800;900&family=Raleway:wght@100;200;300;400;500;600;700;800;900&display=swap" rel="stylesheet">

    Bootstrap CSS -->
    <!-- <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet"> -->

    <!-- Template CSS -->
    <link rel="stylesheet" href="{{ asset('asset/css/main.css') }}">

</head>
<body>
<header id="header" class="fixed-top d-flex align-items-center">
  <div class="container d-flex justify-content-between">
    <h1 class="logo"><a href="{{ route('index') }}">Medicio</a></h1>
    <nav id="navbar" class="navbar">
      <ul>
        <li><a href="{{ route('index') }}">Home</a></li>
        <li><a href="{{ route('about') }}">About</a></li>
        <li><a href="{{ route('services') }}">Services</a></li>
        <li><a href="{{ route('department') }}">Departments</a></li>
        <li><a href="{{ route('doctor') }}">Doctors</a></li>
        <li><a href="{{ route('contact') }}">Contact</a></li>
        <li><a class="getstarted" href="#appointment">Make an Appointment</a></li>
      </ul>
      <i class="bi bi-list mobile-nav-toggle"></i>
    </nav>
  </div>
</header>

    

    <main>
        @yield('content')
    </main>

 <footer id="footer" class="footer">
  <div class="container">
    <div class="row">
      <div class="col-lg-4 col-md-6">
        <h4>Medicio</h4>
        <p>A108 Adam Street, New York, NY 535022<br>Phone: +1 5589 55488 55<br>Email: info@example.com</p>
      </div>
      <div class="col-lg-4 col-md-6">
        <h4>Useful Links</h4>
        <ul>
          <li><a href="{{ route('index') }}">Home</a></li>
          <li><a href="{{ route('about') }}">About us</a></li>
          <li><a href="{{ route('services') }}">Services</a></li>
          <li><a href="{{ route('contact') }}">Contact</a></li>
        </ul>
      </div>
    </div>
  </div>
  <div class="container text-center">
    &copy; Copyright Medicio All Rights Reserved
  </div>
</footer>


    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="{{ asset('asset/js/main.js') }}"></script>
</body>
</html>
